import teamlab_forklift_ds as ds
filename = "forklist_move.csv"
dataset = ds.load_dataset(filename)
sorted_result = ds.sort_dataset(dataset)
result = ds.build_linkedlistbag(sorted_result)['TEAM10054239']
print(result)
for i in result:
    print(i)
    
#result.append("2019-06-01 08:30:50.590")
# result.insert("2019-06-01 08:30:50.590")
# print(result)
# print(result.len())
# print(result.iter())


